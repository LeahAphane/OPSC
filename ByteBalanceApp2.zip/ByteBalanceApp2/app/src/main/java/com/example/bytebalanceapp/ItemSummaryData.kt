package com.example.bytebalanceapp

data class ItemSummaryData(
    val category: String,
    val totalAmount: Double,

)
