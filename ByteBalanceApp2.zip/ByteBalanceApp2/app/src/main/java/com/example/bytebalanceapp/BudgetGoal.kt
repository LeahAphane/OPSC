package com.example.bytebalanceapp

data class BudgetGoal(
    val month: String,
    val minGoal: Double,
    val maxGoal: Double
)
